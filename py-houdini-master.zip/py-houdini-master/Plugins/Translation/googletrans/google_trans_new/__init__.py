# coding:utf-8
# author LuShan
# version : 1.1.9
__all__ = 'google_translator'
__version__ = '1.1.9'

from .google_trans_new import google_translator
from .constant import DEFAULT_SERVICE_URLS, LANGUAGES