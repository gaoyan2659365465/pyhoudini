# WesLib




## 安装

将文件放至

    我的文档/houdini(相关版本)/packages

    <比如> 我的文档/houdini19.0/packages
    
如果只想使用hda的话，
只需要删除掉WesLib文件夹内除了otls的其他文件夹

或拷贝WesLib/otls内的.hda文件到

    我的文档/houdini(相关版本)/otls





## 还有..
* 使用说明后续会尽快更新
* 使用中有需求和问题的话及时联系我哦
Guide Document will be updated soon
Contact me if you have any issue


---------------------------



## INSTALLATION

Place files to 

    MyDocument/houdini(version)/packages
    
    <Exsample> MyDocument/houdini19.0/packages

If you only want to use HDA,
just delete all the folders inside WesLib except "/otls"

or just copy the .hda files inside WesLib/otls to "MyDocument/houdini(version)/otls"

## And..
* Guide Document will be updated soon
* Contact me if you have any issue
