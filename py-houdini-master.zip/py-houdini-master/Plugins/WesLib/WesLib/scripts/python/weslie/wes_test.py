# -*- coding: utf-8 -*-


test = "操"

print (test)