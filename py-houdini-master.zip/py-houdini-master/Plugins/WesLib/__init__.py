# -*- coding: utf-8 -*-

__name__ = 'WeLib'
__author__ = '柯哀的眼'
__version__ = '0.1'

try:
    from WesLib.WesLib.scripts.python.weslie.wes_ProjBrowser import *
except:
    pass
